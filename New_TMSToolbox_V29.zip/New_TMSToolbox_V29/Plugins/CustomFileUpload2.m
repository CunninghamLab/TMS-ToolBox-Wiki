%Custom File Upload

function [numChannels,numBlocks,Block,AllSampleRate,EventTypeOptions,Data,CommentLocAll,numTrialsC,CommentTxtOptions]=CustomFileUpload2(app)
numChannels=0;
numBlocks=0;
Block=struct();
AllSampleRate=0;
EventTypeOptions=[1];
Data=[];
CommentLocAll=cell(1,1);
numTrialsC=[];
CommentTxtOptions="";


disp('Custom File Upload 2');



end %end function




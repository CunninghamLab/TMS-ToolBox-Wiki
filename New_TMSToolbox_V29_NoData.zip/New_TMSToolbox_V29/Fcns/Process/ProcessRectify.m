%Rectify data
%Inputs: data
%Outputs: rectified data

function RecData=ProcessRectify(Data)

%Rectify data
RecData=abs(Data);

end